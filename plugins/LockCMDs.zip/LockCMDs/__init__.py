import os
import json
import logging

# Full path to this plugin
PATH = os.path.dirname(os.path.realpath(__file__))

# Read config
with open(PATH + "/config.json", "r") as file:
    config = json.load(file)

# Get settings
protectionKey = config["settings"]["key"]
protectedCommands = config["settings"]["commands"]

# Commands listener
def command_handler(content):
    # Protect commands
    if(content["command"] in protectedCommands):
        # If post data don't have 'command_key' value
        if(not "command_key" in content):
            return (True, "Hey, 'command_key' value required in this API request!")
        # If key is wrong
        if(content["command_key"] != protectionKey):
            logging.info("Incorrect server root key.")
            return (True, "Incorrect root key!")