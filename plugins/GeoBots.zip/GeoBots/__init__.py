from core.client import Client
from geolite2 import geolite2

def command_handler(content):

    if(content["command"] == "CLIENT_GET_BOTS_GEO"):
        # Get auth data
        try:
            username = content["username"]
            password = content["password"]
        except KeyError:
            return (False, "Failed to find client username or password!")
        else:
            client = Client(username, password)
            bots = client.GetBots()

        # If errors in API
        if(not bots[0]):
            return (False, bots[1])
        
        # Add GEO data to all bots
        geo_reader = geolite2.reader()
        for index, bot in enumerate(bots[1]):
            geo_data = geo_reader.get(bot["remote_ip"])
            bots[1][index]["geo-data"] = geo_data
        geolite2.close()

        return bots
