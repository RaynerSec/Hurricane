import os
#from core.bot import Bot
#from core.client import Client


# command_handler эта функция позволяет делать свои команды,
# а так-же заменять оригинальные и устанавливать вывод к клиенту.
# ВНИМАНИЕ если в 2х плагинах будет 2 одинаковые команды то выполниться только 1 из них.
def command_handler(content):
    # Вывод в консоль
    print("received new command", content)

    # Если установлено True то это значит что
    # при выполнении возникли ошибки.
    errors = False

    # Тут мы создаём свои команды
    if content["command"] == "EXAMPLE_PLUGIN_TEST":
        message = {"a": "hello", "b": 123, "c": [1, 2, 3]}
        # Вывод сервера:  https://i.ibb.co/cFDMGTQ/EXAMPLE-PLUGIN-TEST.png

    # Тут мы сделали команду которая генерирует рандомную строку
    elif content["command"] == "EXAMPLE_PLUGIN_URANDOM":
        message = os.urandom(32).decode('latin1')
        # Вывод сервера: https://i.ibb.co/zmstgkT/EXAMPLE-PLUGIN-URANDOM.png

    # Тут команда с ошибкой
    elif content["command"] == "EXAMPLE_PLUGIN_ERROR":
        errors  = True
        message = "Message with error"
        # Вывод сервера: https://i.ibb.co/hxGqz7p/EXAMPLE-PLUGIN-ERROR.png 
    
    # Это выполниться если клиент не отправил нужной команды к серверу
    else:
        # Возвращение None значит что изменений нет.
        # Всегда используйте его, если нет команд которые
        # ожидает ваш плагин.
        return None

    # Возвращаем все обработаные значения
    return (errors, message)


# input_handler все входящие запросы к серверу,
# плагин их может прочитать и изменить, сервер увидит уже измененный.
def input_handler(content):
    # Вывод в консоль
    print("received client request: ", content)
    # добавим свой контент в запрос к серверу
    content["input_modificated"] = "changed by example plugin"
    # отдадим это назад серверу
    return content

# output_handler это все ответы сервера к клиенту,
# плагин может изменить ответ клиенту.
def output_handler(content):
    # Вывод в консоль
    print("received server response: ", content)
    # добавим свою инфу в вывод к клиенту
    content["output_modificated"] = "changed by example plugin"
    # отдадим это назад серверу
    return content